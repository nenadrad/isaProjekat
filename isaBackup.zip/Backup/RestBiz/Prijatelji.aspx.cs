﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RestBiz.DataLayer;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace RestBiz
{
    public partial class Prijatelji : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ((Site)this.Master).MarkAsSelected("PrijateljiLink");

                using (var ctx = new RestBizContext())
                {
                    string userEmail = HttpContext.Current.User.Identity.Name;
                    KorisniciRepeater.DataSource = (from k in ctx.Korisnici where k.Email != userEmail select k).ToList<Korisnik>();
                    KorisniciRepeater.DataBind();
                }
            }


        }

        [WebMethod]
        public static string AddFriend(int id)
        {
            string retVal = "nista";
            using (var ctx = new RestBizContext())
            {
                var prijatelj = ctx.Korisnici.Find(id);
                if (prijatelj == null)
                    retVal = "null je";
                else
                {
                    retVal = prijatelj.ImePrezime;
                    string userEmail = System.Web.HttpContext.Current.User.Identity.Name;
                    var korisnik = (from k in ctx.Korisnici where k.Email == userEmail select k).FirstOrDefault<Korisnik>();
                    retVal += " dodaje " + korisnik.ImePrezime;
                    korisnik.Prijatelji.Add(prijatelj);
                    ctx.SaveChanges();
                }
            }

            return new JavaScriptSerializer().Serialize(retVal);
        }
    }
}