﻿function addFriend(friendId) {

	var value = JSON.stringify({
		id : friendId
	});

	$.ajax({
            type: "POST",
            url: "Prijatelji.aspx/AddFriend",
            data: value,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
            	var response = JSON.parse(data.d);
            	alert("uspesno dodat: " + response);
            }
        });
}