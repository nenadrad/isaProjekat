﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using RestBiz.DataLayer;

namespace RestBiz
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            using (RestBizContext ctx = new RestBizContext())
            {
                new RestBizDBInitializer().InitializeDatabase(ctx);
            }

            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                Response.Redirect("Default.aspx");
            }

        }

        protected void LoginUser_Authenticate(object sender, AuthenticateEventArgs e)
        {
            bool status = false;
            status = Membership.ValidateUser(LoginUser.UserName, LoginUser.Password);
            if (status)
            {
                FormsAuthentication.RedirectFromLoginPage(LoginUser.UserName, false);
                Session["User"] = LoginUser.UserName;
               
            }
           
        }
    }
}